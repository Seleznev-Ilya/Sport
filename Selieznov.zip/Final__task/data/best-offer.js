window.bestOffer = {
    discount: 15,
    left: [
        '8c061815-6a7d-4465-bb78-1bdc6c5adebf', // Only Skinny Jeans
        'e50a3153-7833-4b85-b412-1a39d215fd38', // Oversized Cardigan
        'bec71daa-d133-473d-bbb0-1ee0a427a17d' // Only Busted Knee Jean
    ],
    right: [
        '5677f851-1c4a-4e9b-80e9-16d1e6265257', // Levi's Jeans for women,
        '07cf6ce2-6eee-4e78-a441-f257fdea7ed6' // Boyfriend T-Shirt with Bohemian print


    ]
};
